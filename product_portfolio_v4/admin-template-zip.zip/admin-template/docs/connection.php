<?php
$conn = mysqli_connect("localhost", "root", "", "product_portfolio_db");
if (!$conn) {
    echo "Connection Failed";
}
