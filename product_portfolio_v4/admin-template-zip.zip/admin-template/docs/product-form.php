<?php
session_start();
include "header.php";
?>
<!-- Sidebar menu-->
<?php
include 'aside.php';
?>
<main class="app-content">
    <div class="app-title">
        <div>
            <h1><i class="fa fa-edit"></i>Product Form</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
            <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
            <li class="breadcrumb-item">Forms</li>
            <li class="breadcrumb-item"><a href="#">Products Form</a></li>
        </ul>
    </div>
    <div class="col-md-6" style="text-align:left;">
        <div class="tile">
            <h3 class="tile-title">Product Details</h3>
            <div class="tile-body">
                <form class="form-horizontal" method="post" enctype="multipart/form-data" action="product-form-process.php">
                    <div class="form-group row">
                        <label class="control-label col-md-3">Name</label>
                        <div class="col-md-8">
                            <input class="form-control" type="text" placeholder="Enter product's name" name="product_name" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="control-label col-md-3">Description</label>
                        <div class="col-md-8">
                            <textarea class="form-control" placeholder="Product Desciption" rows="5" cols="40" name="product_description"></textarea>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="control-label col-md-3">Product Category</label>
                        <div class="col-md-8">
                            <!--<input class="form-control" type="text" placeholder="Enter category" name="item_category">-->
                            <select class="form-control col-md-15" name="category_id">
                                <option selected>-------None-------</option>
                                <?php
                                include 'connection.php';
                                $q = mysqli_query($conn, "select * from category");
                                while ($row = mysqli_fetch_array($q)) {
                                    //echo "<option value=".$row['sector_id'].">". $row['sector_name']." </option>";
                                    echo "<option value='{$row['category_id']}'> {$row['category_name']} </option>";
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="control-label col-md-3">Product MRP</label>
                        <div class="col-md-8">
                            <input class="form-control" type="number" placeholder="Enter MRP of Product" name="product_mrp" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="control-label col-md-3">Discount (in percentage)</label>
                        <div class="col-md-8">
                            <input class="form-control" type="number" placeholder="Enter discount (if any)" name="product_discount">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="control-label col-md-3">Availabilty of Product</label>
                        <div class="col-md-8">
                            <input class="form-control" type="number" placeholder="Enter no. of available product" name="no_of_items" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="control-label col-md-3">Color</label>
                        <div class="col-md-8">
                            <input class="form-control" type="text" placeholder="Enter product's color" name="product_color" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="control-label col-md-3">Product image (.jpg format)</label>
                        <div class="col-md-8">
                            <input class="form-control" type="file" placeholder="Choose File" name="product_image" accept=".jpg" required>
                        </div>
                    </div>
                    <!--<div class="form-group row">
                  <label class="control-label col-md-3">Identity Proof</label>
                  <div class="col-md-8">
                    <input class="form-control" type="file">
                  </div>
                </div>-->

            </div>
            <div class="tile-footer">
                <div class="row">
                    <div class="col-md-8 col-md-offset-3">
                        <input type="submit" value="Submit" name="submit11" class="btn btn-primary" style="background-color: #164d19;border:2px solid #164d19">&nbsp;&nbsp;&nbsp;<input type="reset" name="reset" value="Cancel" class="btn btn-secondary" href="#">
                    </div>
                </div>
            </div>
            </form>
        </div>
    </div>
    </div>
</main>
<!-- Essential javascripts for application to work-->
<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/main.js"></script>
<!-- The javascript plugin to display page loading on top-->
<script src="js/plugins/pace.min.js"></script>
<!-- Page specific javascripts-->
<?php
include "script.php";
?>
</body>

</html>