<?php
include 'connection.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['admin_username'];
    $password = $_POST['admin_password'];
    $name = $_POST['admin_name'];
    $sql = "insert into admin (admin_username,password,admin_name) values('$username','$password','$name)";

    if (mysqli_query($conn, $sql)) {
        echo "<script>window.location='admin-table.php';</script>";
    } else {
        echo "Problem" . mysqli_error($conn);
    }
}
