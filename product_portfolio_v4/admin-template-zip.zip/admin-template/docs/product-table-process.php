
<?php
include 'connection.php';

if (isset($_GET['did'])) {
    $id = $_GET['did'];
    $did = mysqli_query($conn, "delete from product where product_id ='{$id}'");
    if ($did) {
        echo "<script>alert('Record Deleted');window.location='product-table.php';</script>";
    } else {
        echo "<script>alert('Record Not Deleted');window.location='product-table.php';</script>";
    }
}
$q = "select * from product";
$r = mysqli_query($conn, $q);
$i = 1;
while ($row = mysqli_fetch_array($r)) {
    echo "<tr>";
    echo "<td>" . $i . "</td>";
    echo "<td>" . $row['product_name'] . "</td>";
    echo "<td>" . $row['product_description'] . "</td>";
    echo "<td>" . $row['category_id'] . "</td>";
    echo "<td>" . $row['product_mrp'] . "</td>";
    echo "<td>" . $row['product_discount'] . "</td>";
    echo "<td>" . $row['no_of_items'] . "</td>";
    echo "<td>" . $row['product_color'] . "</td>";
    echo "<td>" . $row['product_image'] . "</td>";
    //echo "<td><a href='product-edit.php?pid={$row['product_id']}'>Edit</a> | <a href='product-table-process.php?did={$row['product_id']}'>Delete</a> </td>";
    echo "<td><a href='product-table-process.php?did={$row['product_id']}'>Delete</a> </td>";
    echo "</tr>";
    $i++;
}
?>