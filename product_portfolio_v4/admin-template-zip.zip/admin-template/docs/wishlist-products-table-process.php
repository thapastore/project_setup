
<?php
include 'connection.php';

if (isset($_GET['did'])) {
    $id = $_GET['did'];
    $did = mysqli_query($conn, "delete from wishlist_products where wishlist_product_id	 ='{$id}'");
    if ($did) {
        echo "<script>alert('Record Deleted');window.location='wishlist-products-table.php';</script>";
    } else {
        echo "<script>alert('Record Not Deleted');window.location='wishlist-products-table.php';</script>";
    }
}
$q = "select * from wishlist_products";
$r = mysqli_query($conn, $q);
$i = 1;
while ($row = mysqli_fetch_array($r)) {
    echo "<tr>";
    echo "<td>" . $i . "</td>";
    echo "<td>" . $row['wishlist_id'] . "</td>";
    echo "<td>" . $row['product_id'] . "</td>";
    //echo "<td><a href='product-edit.php?pid={$row['product_id']}'>Edit</a> | <a href='product-table-process.php?did={$row['product_id']}'>Delete</a> </td>";
    echo "<td><a href='wishlist-products-table-process.php?did={$row['wishlist_product_id']}'>Delete</a> </td>";
    echo "</tr>";
    $i++;
}
?>