
<?php
include 'connection.php';

if (isset($_GET['did'])) {
    $id = $_GET['did'];
    $did = mysqli_query($conn, "delete from product_review where product_review_id 	 ='{$id}'");
    if ($did) {
        echo "<script>alert('Record Deleted');window.location='product-review-table.php';</script>";
    } else {
        echo "<script>alert('Record Not Deleted');window.location='product-review-table.php';</script>";
    }
}
$q = "select * from product_review";
$r = mysqli_query($conn, $q);
$i = 1;
while ($row = mysqli_fetch_array($r)) {
    echo "<tr>";
    echo "<td>" . $i . "</td>";
    echo "<td>" . $row['product_id'] . "</td>";
    echo "<td>" . $row['product_rating'] . "</td>";
    echo "<td>" . $row['product_feedback'] . "</td>";
    echo "<td>" . $row['product_review_image'] . "</td>";
    //echo "<td><a href='product-edit.php?pid={$row['product_id']}'>Edit</a> | <a href='product-table-process.php?did={$row['product_id']}'>Delete</a> </td>";
    echo "<td><a href='product-review-table-process.php?did={$row['product_review_id']}'>Delete</a> </td>";
    echo "</tr>";
    $i++;
}
?>