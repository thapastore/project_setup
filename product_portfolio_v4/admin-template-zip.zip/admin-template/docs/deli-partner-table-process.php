
<?php
include 'connection.php';

if (isset($_GET['did'])) {
    $id = $_GET['did'];
    $did = mysqli_query($conn, "delete from delivery_partner where delivery_partner_id ='{$id}'");
    if ($did) {
        echo "<script>alert('Record Deleted');window.location=deli-partner-table.php';</script>";
    } else {
        echo "<script>alert('Record Not Deleted');window.location='deli-partner-table.php';</script>";
    }
}
$q = "select * from delivery_partner";
$r = mysqli_query($conn, $q);
$i = 1;
while ($row = mysqli_fetch_array($r)) {
    echo "<tr>";
    echo "<td>" . $i . "</td>";
    echo "<td>" . $row['dp_contact_no'] . "</td>";
    echo "<td>" . $row['dp_name'] . "</td>";
    echo "<td>" . $row['dp_email'] . "</td>";
    echo "<td>" . $row['dp_address'] . "</td>";
    echo "<td>" . $row['identity_proof'] . "</td>";
    //echo "<td><a href='product-edit.php?pid={$row['product_id']}'>Edit</a> | <a href='product-table-process.php?did={$row['product_id']}'>Delete</a> </td>";
    echo "<td><a href='deli-partner-table-process.php?did={$row['delivery_partner_id']}'>Delete</a> </td>";
    echo "</tr>";
    $i++;
}
?>