<?php
include 'connection.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['product_name'];
    $detail = mysqli_real_escape_string($conn, $_POST['product_description']);
    $cat = $_POST['category_id'];
    $mrp = $_POST['product_mrp'];
    $discount = $_POST['product_discount'];
    $avail = $_POST['no_of_items'];
    $color = $_POST['product_color'];
    $image = $_FILES['product_image']['name'];
    $path = $_FILES['product_image']['tmp_name'];
    $sql = "insert into product (product_name,product_description,category_id,product_mrp,product_discount,no_of_items,product_color,product_image) values('$name','$detail','$cat','$mrp','$discount','$avail','$color','$image')";

    if (mysqli_query($conn, $sql)) {
        move_uploaded_file($path, "../../admin-template/docs/product-uploads/" . $image);
        echo "<script>window.location='product-table.php';</script>";
    } else {
        echo "Problem" . mysqli_error($conn);
    }
}
