
<?php
include 'connection.php';

if (isset($_GET['did'])) {
    $id = $_GET['did'];
    $did = mysqli_query($conn, "delete from orders where order_id ='{$id}'");
    if ($did) {
        echo "<script>alert('Record Deleted');window.location='orders-table.php';</script>";
    } else {
        echo "<script>alert('Record Not Deleted');window.location='orders-table.php';</script>";
    }
}
$q = "select * from orders";
$r = mysqli_query($conn, $q);
$i = 1;
while ($row = mysqli_fetch_array($r)) {
    echo "<tr>";
    echo "<td>" . $i . "</td>";
    echo "<td>" . $row['user_id'] . "</td>";
    echo "<td>" . $row['order_date'] . "</td>";
    echo "<td>" . $row['order_option'] . "</td>";
    echo "<td>" . $row['total_amount'] . "</td>";
    echo "<td>" . $row['coupon_code'] . "</td>";
    echo "<td>" . $row['delivery_status'] . "</td>";
    //echo "<td><a href='product-edit.php?pid={$row['product_id']}'>Edit</a> | <a href='product-table-process.php?did={$row['product_id']}'>Delete</a> </td>";
    echo "<td><a href='orders-table-process.php?did={$row['order_id']}'>Delete</a> </td>";
    echo "</tr>";
    $i++;
}
?>