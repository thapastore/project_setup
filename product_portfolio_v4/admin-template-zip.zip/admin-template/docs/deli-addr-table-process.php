<?php
include 'connection.php';

if (isset($_GET['did'])) {
    $id = $_GET['did'];
    $did = mysqli_query($conn, "delete from delivery_address where delivery_address_id ='{$id}'");
    if ($did) {
        echo "<script>alert('Record Deleted');window.location='delivery-address-table.php';</script>";
    } else {
        echo "<script>alert('Record Not Deleted');window.location='delivery-address-table.php';</script>";
    }
}
$q = "select * from delivery_address";
$r = mysqli_query($conn, $q);
$i = 1;
while ($row = mysqli_fetch_array($r)) {
    echo "<tr>";
    echo "<td>" . $i . "</td>";
    echo "<td>" . $row['user_id'] . "</td>";
    echo "<td>" . $row['street'] . "</td>";
    echo "<td>" . $row['city'] . "</td>";
    echo "<td>" . $row['state'] . "</td>";
    echo "<td>" . $row['zip_code'] . "</td>";
    echo "<td>" . $row['country'] . "</td>";
    //echo "<td><a href='product-edit.php?pid={$row['product_id']}'>Edit</a> | <a href='product-table-process.php?did={$row['product_id']}'>Delete</a> </td>";
    echo "<td><a href='deli-addr-table-process.php?did={$row['user_id']}'>Delete</a> </td>";
    echo "</tr>";
    $i++;
}
